################################################################################
# R code for analysis of simulated survey data from within WA zipcodes

### Change the directory to match your working directory ###
dir<-"/SpatialSurveyExample"
setwd(dir)
tol <- 10^{-7}
# load R libraries
library(maptools); library(maps); library(RColorBrewer);
library(shapefiles); 
library(INLA);library(MASS)
library(survey)

# load my functions
source(paste(dir, "/functions.R", sep=""))


################################################################################
#-------------------------------#
# read in zipcode shapefiles 
zipcode.shp <- readShapePoly(
paste(dir, "/WAzipShapefiles/xxpoly", sep=""))
plot(zipcode.shp, axes=TRUE)
dim(zipcode.shp)
zipcode.shp@data[1:5,]
zipcode <- data.frame(ID=1:nrow(zipcode.shp@data), area=zipcode.shp@data$zip_1)
head(zipcode)
n.area <- nrow(zipcode)

##### Read in Census Data ######

census<-read.csv("age_gender_strata.csv")
N.i<-data.frame(area=census[,1],fpc=apply(census[,2:7],1,sum))
N.j<-apply(census,2,sum)[2:7]

n.strat<-6

##### Read in Survey data ########
sim.survey<-read.csv("survey.csv")

######-------- post-stratification-------------########
# poststratification based on strata
N.hat.j<- aggregate(sim.survey$wt1, by=list(sim.survey$strat), FUN=sum) 
# post-stratification weight
ratio <- N.j/N.hat.j 
ratio <- ratio$x
wt2.strat <- data.frame(strat=1:n.strat, wt2=ratio)

# assign poststratification weight
sim.survey <- merge(sim.survey, wt2.strat, by="strat")

# final weight is: wt1*wt2
sim.survey$wt <- sim.survey$wt1 * sim.survey$wt2 


#-----------------------------------------------------------------#
# define p.hat.j
sim.survey$prod <- sim.survey$diat * sim.survey$wt
numt <-  aggregate(sim.survey$prod, by=list(sim.survey$strat), FUN=sum)
denot <-  aggregate(sim.survey$wt, by=list(sim.survey$strat), FUN=sum)
p.hat.j <- numt$x/denot$x
p.hat.j <- data.frame(strat=1:length(p.hat.j), p.hat.j=p.hat.j)

summary(p.hat.j)

datan.bystrat <- data.bystrat(data=sim.survey, area=zipcode$area, n.strat=n.strat, resp.col="diat", strat.col="strat")

sim.survey2 <- merge(sim.survey, N.i, by="area")
my.svydesign <- svydesign(id= ~1, strata=~area, weights= ~ wt1, data=sim.survey2, fpc=~fpc)

## with postStratify
pop.types <- data.frame(strat=1:6, Freq=c(N.j)) 
my.svydesignp <- postStratify(my.svydesign, ~strat, pop.types)

TL.est.p <- svyby(~diat, ~area, svymean, design=my.svydesignp)
head(TL.est.p)


#####-------- calculate adjusted m*, y*  for each of the small area
m.star <- y.star <- m <- y <- p.star <- TL.var <-  rep(NA, n.area)


#######################################
####------need to calculate m.star, p.star for each area------####
#######################################
for (l in 1:n.area){	
#l<-9
tmp <- sim.survey[sim.survey$area==census$area[l],]

# observed sample size and number of observation
m[l] <- nrow(tmp)
y[l] <- sum(tmp$diat)

#-----------  calculate m.star, y.star, using Survey package

##--------- WITH post-stratification weight---------##
TL.est.tmp <- TL.est.p$diat[l] 
TL.est.tmp.var <- (TL.est.p$se[l])^2
TL.var[l]<-	TL.est.tmp.var
m.star[l] <- TL.est.tmp*(1-TL.est.tmp)/TL.est.tmp.var
y.star[l] <- TL.est.tmp*m.star[l]

# if m and popn are the same, m.star and y.star is m and y
#if (m[l] == datan$popn[l]){
  #m.star[l] <- m[l]
  #y.star[l] <- y[l]}
}

# Bayesian shrinkage models
p.star<-y.star/m.star
simdata <- data.frame(area=census$area, m=m, y=y, m.star=m.star, y.star=y.star,p.star=p.star,y.dag=m*p.star)

### needed for INLA ###
simdata$region.unstruct <- 1:nrow(simdata)
simdata$region.struct <- 1:nrow(simdata)

### outcome and precision for arcsin sqrt model ###
simdata$sin.p<-asin(sqrt(simdata$p.star))
simdata$sin.prec<-4*simdata$m.star

### outcome and precision for logit normal model ###
simdata$logit.p<-log(simdata$p.star/(1-simdata$p.star))
simdata$logit.prec<-1/TL.var * (simdata$p.star*(1-simdata$p.star))^2



##################### Random Effects Models ###################

## Unadjusted Binomial ##
mod.1 <- normRE.model(simdata, method="unadjusted",spatial=F)

## Effective Sample Size ##
mod.2 <- normRE.model(simdata, method="adjusted",spatial=F)

## Logit Normal ##
mod.3<-norm.logit.model(simdata,spatial=F)

## Inverse sin sqrt model ## 
mod.4<-isp.model(simdata,spatial=F)

## Psuedo Likelihood ##
mod.5 <- normRE.model(simdata, method="weighted",spatial=F)


######################## spatial models ########################
graph.loc<-paste(dir, "/WAzipShapefiles/WAZIP_v2.graph", sep="")
## Unadjusted Binomial ##
mod.1s <- normRE.model(simdata, method="unadjusted",spatial=T,graph.dir=graph.loc)

## Effective Sample Size ##
mod.2s <- normRE.model(simdata, method="adjusted",spatial=T,graph.dir=graph.loc)

## Logit Normal ##
mod.3s<-norm.logit.model(simdata,spatial=T,graph.dir=graph.loc)

## Inverse sin sqrt model ## 
mod.4s<-isp.model(simdata,spatial=T,graph.dir=graph.loc)

## Psuedo Likelihood ##
mod.5s <- normRE.model(simdata, method="weighted",spatial=T,graph.dir=graph.loc)
