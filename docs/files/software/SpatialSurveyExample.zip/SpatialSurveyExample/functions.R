###############################################################################
# functions to fit models to be sources by SAE_example.R
###############################################################################

##########################################################################
# model: function to fit a norm random effect model in INLA
# binomial fit
library(INLA)
graph.loc<- "/WAzipShapefiles/WAZIP_v2.graph"
normRE.model <- function(simdata, method,spatial,graph.dir){
# used adjusted methods
if(method == "unadjusted"){
	if(spatial==FALSE){
  
  	formula <- y ~ f(region.unstruct,model="iid", param=c(0.5,0.008)) }
  
 	if(spatial==TRUE){
 		
 	formula = y ~f(region.struct,model="besag", graph.file=graph.loc, param=c(0.5,0.008)) + f(region.unstruct,model="iid", param=c(0.5,0.008)) }	


mod <- inla(formula, family = "binomial", data = simdata, Ntrials=m,control.predictor=list(compute=TRUE))
}

if(method == "adjusted"){
	
	if(spatial==TRUE){
	
	formula = y.star ~f(region.struct,model="besag", graph.file=graph.loc,param=c(0.5,0.008))  + f(region.unstruct,model="iid", param=c(0.5,0.008))}

 	if(spatial==FALSE){ 
 	
 	formula <- y.star ~ f(region.unstruct,model="iid", param=c(0.5,0.008)) }

mod <- inla(formula, family = "binomial", data = simdata, Ntrials=m.star,control.predictor=list(compute=TRUE))  
}
if(method == "weighted"){
	
	if(spatial==TRUE){f
		
	formula <- y.dag ~ f(region.struct,model="besag", graph.file=graph.loc,param=c(0.5,0.008))+f(region.unstruct,model="iid", param=c(0.5,0.008))  }

	if(spatial==FALSE){
  	
  	formula <- y.dag ~ f(region.unstruct,model="iid", param=c(0.5,0.008)) } 

  mod <- inla(formula, family = "binomial", data = simdata, Ntrials=m,control.predictor=list(compute=TRUE))  
}


if(spatial==FALSE){
	# use the posterior median for estimated sigma
	sigma.unstruct <- 1/sqrt(mod$summary.hyperpar[,"0.5quant"])
	# use the posterior mean for estimated p
	p.est <- mod$summary.fitted.values[, "0.5quant"]
	return(list(par=c(intercept=mod$summary.fixed[1],sigma.unstruct=sigma.unstruct),p=p.est))}
	
if(spatial==TRUE){
sigma.struct <- 1/sqrt(mod$summary.hyperpar[1,"0.5quant"])
sigma.unstruct <- 1/sqrt(mod$summary.hyperpar[2,"0.5quant"])
# use the posterior mean for estimated p
p.est <- mod$summary.fitted.values[, "0.5quant"]
return(list(par=c(intercept=mod$summary.fixed[1],sigma.struct=sigma.struct,sigma.unstruct=sigma.unstruct),p=p.est))}
}


##########################################################################
## function to sin^(-1)(sqrt(y.i/n.i)) model in INLA
isp.model <- function(simdata,spatial,graph.dir){
	if(spatial==TRUE){

		formula <- sin.p~ f(region.struct,model="besag", graph.file=graph.loc,param=c(0.5,0.008))+f(region.unstruct,model="iid",param=c(0.5,0.008)) 
	
		}
	if(spatial==FALSE){
		formula = sin.p~ 1 + f(region.unstruct,model="iid",param=c(0.5,0.008)) 
		}
mod <- inla(formula, 
		family = "gaussian", 
		data =simdata, 
		control.predictor=list(compute=TRUE),
		control.family=list(hyper=list(prec=list(initial=log(1),fixed=TRUE))),
		scale=sin.prec)

if(spatial==TRUE){
sigma.struct <- 1/sqrt(mod$summary.hyperpar[1,"0.5quant"])
sigma.unstruct <- 1/sqrt(mod$summary.hyperpar[2,"0.5quant"])
# use the posterior median for estimated p
theta.est <- mod$summary.fitted.values[, "0.5quant"]
p.est<-sin(theta.est)^2
return(list(par=c(intercept=mod$summary.fixed[1],sigma.struct=sigma.struct,sigma.unstruct=sigma.unstruct),p=p.est))}

if(spatial==FALSE){
sigma.unstruct <- 1/sqrt(mod$summary.hyperpar[,"0.5quant"])
# use the posterior median for estimated p
theta.est <- mod$summary.fitted.values[, "0.5quant"]
p.est<-sin(theta.est)^2
return(list(par=c(intercept=mod$summary.fixed[1],sigma.unstruct=sigma.unstruct),p=p.est))}
}

##########################################################################
## function to normal approximation to logit(p) 

norm.logit.model <- function(simdata,spatial,graph.dir){
	if(spatial==TRUE){
	formula = logit.p~1 +f(region.struct,model="besag", graph.file=graph.loc, param=c(0.5,0.008))+f(region.unstruct,model="iid",param=c(0.5,0.008))  
	 
	}
		if(spatial==FALSE){
	formula = logit.p~1 + f(region.unstruct,model="iid",param=c(0.5,0.008)) 
	}
	
	
mod <- inla(formula, 
		family = "gaussian", 
		data =simdata, 
		control.predictor=list(compute=TRUE),
		control.family=list(hyper=list(prec=list(initial=log(1),fixed=TRUE))),
		scale=logit.prec)

if(spatial==FALSE){
sigma.unstruct <- 1/sqrt(mod$summary.hyperpar[,"0.5quant"])
# use the posterior mean for estimated p
logit.p.est <- mod$summary.fitted.values[, "0.5quant"]
p.est<-exp(logit.p.est)/(1 + exp(logit.p.est))
return(list(par=c(intercept=mod$summary.fixed[1],sigma.unstruct=sigma.unstruct),p=p.est))}

if(spatial==TRUE){
sigma.struct <- 1/sqrt(mod$summary.hyperpar[1,"0.5quant"])
sigma.unstruct <- 1/sqrt(mod$summary.hyperpar[2,"0.5quant"])
# use the posterior mean for estimated p
logit.p.est <- mod$summary.fitted.values[, "0.5quant"]
p.est<-exp(logit.p.est)/(1 + exp(logit.p.est))
return(list(par=c(intercept=mod$summary.fixed[1],sigma.struct=sigma.struct,sigma.unstruct=sigma.unstruct),p=p.est))}
}

##########################################################################


##########################################################################
# function data.bystrat stratify the raw data by individual to groups by zipcode and age-gendergroups
data.bystrat <- function(data, area, n.strat, resp.col, strat.col){
  y.strat <- m.strat <- matrix(NA, ncol=n.strat, nrow=length(area))
  row.names(y.strat) <- row.names(m.strat) <- area
  colnames(y.strat) <- colnames(m.strat) <- 1:n.strat
  resp.col.id <- which(colnames(data) == resp.col)
  strat.col.id <- which(colnames(data)== strat.col)
  for (i in 1:length(area)){	
    tmp <- data[data$area==area[i],]
    datan.bystrat <- table(tmp[, c(strat.col.id, resp.col.id)])
    ind <- as.numeric(attributes(datan.bystrat)$dimnames[[1]])
    # if code in 0/1, then change to 1/2 
    if(ind[1]==0){ind <- ind + 1}
    m.strat[i, ind] <- apply(datan.bystrat, 1, sum)
    y.strat[i, ind] <- apply(datan.bystrat, 1, sum) - datan.bystrat[,1]
  }
  return (list(m.bystrat=m.strat, y.bystrat=y.strat))
}



